# ETS Safoene Daoud et Cie — Parts & Tools Room Demo

A standalone automotive workshop inventory demo derived conceptually from the Supply Room Kiosk workflow, rebuilt for ETS Safoene Daoud et Cie.

## Demo logins
- Majdi — PIN `1234`
- Demo Admin — PIN `2026`

Change these before any real production use.

## What it demonstrates
- Generic employee login (no Maintenance / Supervisor / Tele-operator roles)
- Parts and tools inventory
- Consumable spare-part issuing
- Returnable tool checkout / return
- Low-stock dashboard
- Activity/audit trail
- Admin creation of new parts and tools
- Admin creation of new users
- Stock receiving

## Local run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Then open http://localhost:8000

## Docker
```bash
docker build -t safoene-kia-demo .
docker run --rm -p 8000:8000 safoene-kia-demo
```

## Railway
Use a PostgreSQL service and set:
- `DATABASE_URL`
- `JWT_SECRET`
- `SEED_ON_STARTUP=true`
- `PORT=8000`

The app serves both the frontend and FastAPI backend from one container, avoiding the separate nginx/frontend networking issue from the earlier demo.

## Branding note
The KIA logo is used only for demonstration/visualization. KIA is a trademark of Kia Corporation. This project is not an official Kia corporate system.
