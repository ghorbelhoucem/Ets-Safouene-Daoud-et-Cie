import os
import secrets
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy import desc, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .auth import admin_user, current_user, hash_pin, token_for, verify_pin
from .database import Base, SessionLocal, engine, get_db
from .models import Checkout, Item, Movement, User
from .seed import seed

@asynccontextmanager
async def lifespan(_app: FastAPI):
    Base.metadata.create_all(bind=engine)
    if os.getenv("SEED_ON_STARTUP", "true").lower() in {"1", "true", "yes"}:
        db = SessionLocal()
        try:
            seed(db)
        finally:
            db.close()
    yield

app = FastAPI(title="ETS Safoene Daoud et Cie Parts & Tools Room", lifespan=lifespan)

class LoginIn(BaseModel):
    user_id: str
    pin: str = Field(min_length=4, max_length=12)

class TakeIn(BaseModel):
    item_id: str
    qty: int = Field(gt=0)

class ReturnIn(BaseModel):
    checkout_id: str

class ItemIn(BaseModel):
    sku: str = Field(min_length=2, max_length=64)
    name: str = Field(min_length=2, max_length=200)
    category: str
    qty: int = Field(ge=0)
    min_qty: int = Field(ge=0, default=2)
    location: str | None = None

class ReceiveIn(BaseModel):
    item_id: str
    qty: int = Field(gt=0)

class UserIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    pin: str = Field(min_length=4, max_length=12)
    is_admin: bool = False

def item_json(i: Item):
    return {"id": i.id, "sku": i.sku, "name": i.name, "category": i.category, "returnable": i.returnable,
            "qty": i.qty_on_hand, "minQty": i.min_qty, "location": i.location or "", "low": i.qty_on_hand <= i.min_qty}

def checkout_json(c: Checkout):
    return {"id": c.id, "txId": c.tx_id, "itemId": c.item_id, "item": c.item.name if c.item else "Item",
            "user": c.user_name, "qty": c.qty, "takenAt": c.taken_at.isoformat() if c.taken_at else ""}

def movement_json(m: Movement):
    return {"id": m.id, "action": m.action, "item": m.item_name, "qty": m.qty, "actor": m.actor,
            "detail": m.detail or "", "createdAt": m.created_at.isoformat() if m.created_at else ""}

@app.get("/health")
def health():
    return {"ok": True}

@app.get("/api/users")
def users_public(db: Session = Depends(get_db)):
    rows = db.execute(select(User).where(User.is_active.is_(True)).order_by(User.name)).scalars().all()
    return [{"id": u.id, "name": u.name, "isAdmin": u.is_admin} for u in rows]

@app.post("/api/auth/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    user = db.get(User, body.user_id)
    if not user or not user.is_active or not verify_pin(body.pin, user.pin_hash):
        raise HTTPException(status_code=401, detail="Incorrect PIN")
    return {"token": token_for(user), "user": {"id": user.id, "name": user.name, "isAdmin": user.is_admin}}

@app.get("/api/snapshot")
def snapshot(db: Session = Depends(get_db), user: User = Depends(current_user)):
    items = db.execute(select(Item).order_by(Item.category, Item.name)).scalars().all()
    opens = db.execute(select(Checkout).where(Checkout.returned_at.is_(None)).order_by(desc(Checkout.taken_at))).scalars().all()
    moves = db.execute(select(Movement).order_by(desc(Movement.created_at)).limit(80)).scalars().all()
    return {
        "user": {"id": user.id, "name": user.name, "isAdmin": user.is_admin},
        "items": [item_json(i) for i in items],
        "checkouts": [checkout_json(c) for c in opens],
        "movements": [movement_json(m) for m in moves],
    }

@app.post("/api/take")
def take(body: TakeIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    item = db.get(Item, body.item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    if body.qty > item.qty_on_hand:
        raise HTTPException(status_code=400, detail=f"Only {item.qty_on_hand} available")
    item.qty_on_hand -= body.qty
    if item.returnable:
        tx = f"TX-{secrets.token_hex(4).upper()}"
        db.add(Checkout(tx_id=tx, item_id=item.id, user_id=user.id, user_name=user.name, qty=body.qty))
        detail = "Returnable tool checkout"
    else:
        detail = "Spare part issued / consumed"
    db.add(Movement(action="TAKE", item_id=item.id, item_name=item.name, qty=-body.qty, actor=user.name, detail=detail))
    db.commit()
    return {"ok": True}

@app.post("/api/return")
def return_tool(body: ReturnIn, db: Session = Depends(get_db), user: User = Depends(current_user)):
    c = db.get(Checkout, body.checkout_id)
    if not c or c.returned_at is not None:
        raise HTTPException(status_code=404, detail="Open checkout not found")
    item = db.get(Item, c.item_id)
    item.qty_on_hand += c.qty
    c.returned_at = datetime.now(timezone.utc)
    c.returned_by = user.name
    db.add(Movement(action="RETURN", item_id=item.id, item_name=item.name, qty=c.qty, actor=user.name, detail=f"Returned checkout {c.tx_id}"))
    db.commit()
    return {"ok": True}

@app.post("/api/items")
def create_item(body: ItemIn, db: Session = Depends(get_db), user: User = Depends(admin_user)):
    category = body.category.title()
    if category not in {"Part", "Tool"}:
        raise HTTPException(status_code=400, detail="Category must be Part or Tool")
    item = Item(sku=body.sku.strip().upper(), name=body.name.strip(), category=category, returnable=(category == "Tool"),
                qty_on_hand=body.qty, min_qty=body.min_qty, location=(body.location or "").strip() or None)
    db.add(item)
    db.add(Movement(action="CREATE", item_id=item.id, item_name=item.name, qty=body.qty, actor=user.name, detail=f"New {category.lower()} created"))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="SKU or item name already exists")
    return {"ok": True, "item": item_json(item)}

@app.post("/api/stock/receive")
def receive(body: ReceiveIn, db: Session = Depends(get_db), user: User = Depends(admin_user)):
    item = db.get(Item, body.item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    item.qty_on_hand += body.qty
    db.add(Movement(action="RECEIVE", item_id=item.id, item_name=item.name, qty=body.qty, actor=user.name, detail="Stock received"))
    db.commit()
    return {"ok": True}

@app.post("/api/users")
def create_user(body: UserIn, db: Session = Depends(get_db), admin: User = Depends(admin_user)):
    user = User(name=body.name.strip(), pin_hash=hash_pin(body.pin), is_admin=body.is_admin)
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="A user with that name already exists")
    return {"ok": True, "id": user.id}

@app.get("/api/admin/users")
def admin_users(db: Session = Depends(get_db), admin: User = Depends(admin_user)):
    rows = db.execute(select(User).order_by(User.name)).scalars().all()
    return [{"id": u.id, "name": u.name, "isAdmin": u.is_admin, "active": u.is_active} for u in rows]

STATIC = Path(__file__).resolve().parent.parent / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")

@app.get("/")
def root():
    return FileResponse(STATIC / "index.html")

@app.get("/{path:path}")
def spa(path: str):
    file = STATIC / path
    if file.is_file():
        return FileResponse(file)
    return FileResponse(STATIC / "index.html")
