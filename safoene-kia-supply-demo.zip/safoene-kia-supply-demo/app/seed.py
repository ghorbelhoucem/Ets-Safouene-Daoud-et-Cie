from sqlalchemy import select
from sqlalchemy.orm import Session
from .auth import hash_pin
from .models import User, Item

SEED_ITEMS = [
    ("KIA-OF-001", "Oil Filter", "Part", False, 18, 5, "Shelf A1"),
    ("KIA-AF-002", "Air Filter", "Part", False, 12, 4, "Shelf A2"),
    ("KIA-BP-003", "Front Brake Pad Set", "Part", False, 8, 3, "Shelf B1"),
    ("KIA-SP-004", "Spark Plug", "Part", False, 24, 8, "Shelf B2"),
    ("KIA-BULB-005", "Headlamp Bulb", "Part", False, 10, 4, "Shelf C1"),
    ("TOOL-TW-001", "Torque Wrench", "Tool", True, 3, 1, "Tool Wall 1"),
    ("TOOL-IW-002", "Impact Wrench", "Tool", True, 2, 1, "Tool Wall 1"),
    ("TOOL-OBD-003", "OBD Diagnostic Scanner", "Tool", True, 2, 1, "Cabinet D1"),
    ("TOOL-BT-004", "Battery Tester", "Tool", True, 2, 1, "Cabinet D2"),
    ("TOOL-SS-005", "Socket Set", "Tool", True, 4, 1, "Tool Wall 2"),
]

def seed(db: Session):
    if not db.execute(select(User)).first():
        db.add_all([
            User(name="Majdi", pin_hash=hash_pin("1234"), is_admin=False),
            User(name="Demo Admin", pin_hash=hash_pin("2026"), is_admin=True),
        ])
    if not db.execute(select(Item)).first():
        for sku, name, cat, ret, qty, minimum, loc in SEED_ITEMS:
            db.add(Item(sku=sku, name=name, category=cat, returnable=ret, qty_on_hand=qty, min_qty=minimum, location=loc))
    db.commit()
